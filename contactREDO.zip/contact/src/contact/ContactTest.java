package contact;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {
  protected String contactId, firstNameTest, lastNameTest, phoneNumberTest, addressTest;
  protected String tooLongContactId, tooLongFirstName, tooLongLastName,tooLongPhoneNumber, tooShortPhoneNumber, tooLongAddress;

  
  
  //Most of these values are created for testing purposes
  //some values are too long and short to test the lengths of valid inputs
  
  @BeforeEach
  void setUp() {
    contactId = "34545345";
    firstNameTest = "Brad";
    lastNameTest = "Byard";
    phoneNumberTest = "2314451234";
    addressTest = "345 Longmire rd";
    tooLongContactId = "2356237245756473573w45";
    tooLongFirstName = "Super super super long first name";
    tooLongLastName = "-Super super super long last name";
    tooLongPhoneNumber = "23122345343324";
    tooShortPhoneNumber = "231";
    tooLongAddress = "this address at 543 5 mile rd is way to long to be valid";
  }

  //various tests applied here using assert functions with Junit testing
  
  @Test
  void contactTest() {
    Contact contact = new Contact();
    Assertions.assertNull(contact.getContactID());
    Assertions.assertNull(contact.getFirstName());
    Assertions.assertNull(contact.getLastName());
    Assertions.assertNull(contact.getPhoneNumber());
    Assertions.assertNull(contact.getNumberAddress());
  }

  @Test
  void contactIdConstructorTest() {
    Contact contact = new Contact(contactId);
    Assertions.assertEquals(contactId, contact.getContactID());
    Assertions.assertNull(contact.getFirstName());
    Assertions.assertNull(contact.getLastName());
    Assertions.assertNull(contact.getPhoneNumber());
    Assertions.assertNull(contact.getNumberAddress());
  }

  @Test
  void contactIDAndFirstNameConstructorTest() {
    Contact contact = new Contact(contactId, firstNameTest);
    Assertions.assertEquals(contactId, contact.getContactID());
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
    Assertions.assertNull(contact.getLastName());
    Assertions.assertNull(contact.getPhoneNumber());
    Assertions.assertNull(contact.getNumberAddress());
  }

  @Test
  void contactIDAndNameConstructorTest() {
    Contact contact = new Contact(contactId, firstNameTest, lastNameTest);
    Assertions.assertEquals(contactId, contact.getContactID());
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
    Assertions.assertEquals(lastNameTest, contact.getLastName());
    Assertions.assertNull(contact.getPhoneNumber());
    Assertions.assertNull(contact.getNumberAddress());
  }

  @Test
  void contactIDFullNamePhoneNumberConstructorTest() {
    Contact contact =new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest);
    Assertions.assertEquals(contactId, contact.getContactID());
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
    Assertions.assertEquals(lastNameTest, contact.getLastName());
    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
    Assertions.assertNull(contact.getNumberAddress());
  }

  @Test
  void everythingConstructorTest() {
    Contact contact = new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest, addressTest);
    Assertions.assertEquals(contactId, contact.getContactID());
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
    Assertions.assertEquals(lastNameTest, contact.getLastName());
    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
    Assertions.assertEquals(addressTest, contact.getNumberAddress());
  }

  @Test
  void updateFirstNameTest() {
    Contact contact = new Contact();
    Assertions.assertNull(contact.getFirstName());
    contact.updateFirstName(firstNameTest);
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
  }

  @Test
  void updateFirstNameTooLongNullTest() {
    Contact contact = new Contact();
    Assertions.assertNull(contact.getFirstName());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updateFirstName(tooLongFirstName));
    Assertions.assertNull(contact.getFirstName());
  }

  @Test
  void updateFirstNameTooLongTest() {
    Contact contact = new Contact(contactId, firstNameTest);
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updateFirstName(tooLongFirstName));
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
  }

  @Test
  void updateFirstNameNullTest() {
    Contact contact = new Contact(contactId, firstNameTest);
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updateFirstName(null));
    Assertions.assertEquals(firstNameTest, contact.getFirstName());
  }

  @Test
  void updateLastNameTest() {
    Contact contact = new Contact();
    Assertions.assertNull(contact.getLastName());
    contact.updateLastName(lastNameTest);
    Assertions.assertEquals(lastNameTest, contact.getLastName());
  }

  @Test
  void updateLastNameTooLongNullTest() {
    Contact contact = new Contact();
    Assertions.assertNull(contact.getLastName());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updateLastName(tooLongLastName));
    Assertions.assertNull(contact.getLastName());
  }

  @Test
  void updateLastNameTooLongTest() {
    Contact contact = new Contact(contactId, firstNameTest, lastNameTest);
    Assertions.assertEquals(lastNameTest, contact.getLastName());
    Assertions.assertThrows(IllegalArgumentException.class, () -> contact.updateLastName(tooLongLastName));
    Assertions.assertEquals(lastNameTest, contact.getLastName());
  }

  @Test
  void updateLastNameNullTest() {
    Contact contact = new Contact(contactId, firstNameTest, lastNameTest);
    Assertions.assertEquals(lastNameTest, contact.getLastName());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updateLastName(null));
    Assertions.assertEquals(lastNameTest, contact.getLastName());
  }

  @Test
  void updatePhoneNumberTooLongTest() {
    Contact contact = new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest);
    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updatePhoneNumber(tooLongPhoneNumber));
    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
  }

  @Test
  void updatePhoneNumberTooShortTest() {
    Contact contact =new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest);
    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updatePhoneNumber(tooShortPhoneNumber));
    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
  }

  @Test
  void updateAddressTooLongTest() {
    Contact contact = new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest, addressTest);
    Assertions.assertEquals(addressTest, contact.getNumberAddress());
    Assertions.assertThrows(IllegalArgumentException.class,() -> contact.updateAddress(tooLongAddress));
    Assertions.assertEquals(addressTest, contact.getNumberAddress());
  }
}