package contact;

import java.util.*;

public class ContactService {
   
   // Array List of contacts
   private ArrayList<Contact> contacts;

   //generates a new random ID number
   private String newUniqueId() {
		Random rand = new Random(); 
	    return rand.toString();
	  }
   
   // Creates new array list of contacts
   
   public ContactService() {
       contacts = new ArrayList<>();
   }
   
   
   // Adds contact to list 
   
   
   ContactService(String firstName) {
	    contacts.add(new Contact(newUniqueId(), firstName));
	  }

   ContactService(String firstName, String lastName) {
	    contacts.add(new Contact(newUniqueId(), firstName, lastName));
	  }

	ContactService(String firstName, String lastName, String phoneNumber) {
	    contacts.add(new Contact(newUniqueId(), firstName, lastName, phoneNumber));
	  }

	ContactService(String firstName, String lastName, String phoneNumber,String address) {
	    contacts.add(new Contact(newUniqueId(), firstName, lastName, phoneNumber, address));
	  }

	@SuppressWarnings("unused")
	public Contact newContact() {
		Contact contact = new Contact(newUniqueId());
	    contacts.add(contact);
	    return contact;
	  }
   
	@SuppressWarnings("unused")
    public void updateLastName(Contact contact, String lastName) {
	    contact.updateLastName(lastName);
	  }

	@SuppressWarnings("unused")
	public void updatePhoneNumber(Contact contact, String phoneNumber) {
	    contact.updatePhoneNumber(phoneNumber);
	  }

	 @SuppressWarnings("unused")
	 public void updateAddress(Contact contact, String address) {
	    contact.updateAddress(address);
	  }

	  public List<Contact> getContactList() { 
		  return contacts; }

   
   public boolean add(Contact contact) {
       
	   //Is contact present?
       boolean alreadyPresent = false;
       for (Contact currentContact : contacts) {
           if (currentContact.equals(contact)) {
               alreadyPresent = true;
           }
       }
       
       // if present add it, and return true 
       if (!alreadyPresent) {
           contacts.add(contact);
           System.out.println("Contact Added");
           return true;
       
       } else {
           System.out.println("Contact already exists in System");
           return false;
       }
   }

  
   // removes contact with correct contactId if present in list 
   
   public boolean remove(String contactID) {
       for (Contact currentContact : contacts) {
           if (currentContact.getContactID().equals(contactID)) {
               contacts.remove(currentContact);
               System.out.println("Contact removed Successfully!");
               return true;
           }
       }
       System.out.println("Contact not present");
       return false;
   }

   
   //Updates contact of given contactID
   //if found updates its first name, last name, number address, and phone 
   
   
   public boolean update(String contactID, String firstName, String lastName, String numberAddress, String phoneNumber) {
       for (Contact currentContact : contacts) {
           
    	   //If statements below also check to confirms variables are of proper length, 10 or 30)
    	   
    	   if (currentContact.getContactID().equals(contactID)) {
               if (!(firstName.length() > 10) && firstName != null)
            	   currentContact.setFirstName(firstName);
               if(!(lastName.length() > 10) && lastName != null)
            	   currentContact.setLastName(lastName);
               if (!(numberAddress.length() > 30) && numberAddress != null)
            	   currentContact.setNumberAddress(numberAddress);
               if (!(phoneNumber.length() == 10) && phoneNumber !=null)
            	   currentContact.setPhoneNumber(phoneNumber);
               System.out.println("Contact updated");
               return true;
           }
       }
       System.out.println("Contact not present");
       return false;
   }

}





