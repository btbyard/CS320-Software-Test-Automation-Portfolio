package contact;

public class Driver {

	public static void main(String[] args) { 
		
		
		//System.out.println("Hello World");

		
		//Print intialized data
		
		System.out.println(Contact.contactID);
		System.out.println(Contact.firstName);
		System.out.println(Contact.lastName);
		System.out.println(Contact.numberAddress);
		System.out.println(Contact.phoneNumber);
		
	}
}