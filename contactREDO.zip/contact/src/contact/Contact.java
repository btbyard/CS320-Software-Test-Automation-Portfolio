package contact;


public class Contact {

   //Constants used for limits of length 
   private static final int PHONE_LENGTH = 10;
   private static final byte ID_LENGTH = 10;
   private static final byte FNAME_LENGTH = 10;
   private static final byte LNAME_LENGTH = 10;
   private static final byte ADDRESS_LENGTH = 30;
   
  //Variables for each block of data
   public static String contactID;
   public static String firstName;
   public static String lastName;
   public static String numberAddress;
   public static String phoneNumber;
   private static final String empty = "no data yet provided";
   
   // Constructor initialized with real values, so they aren't Null
   
   public Contact() {
	   
       contactID = "1";
       firstName = "Bradley";
       lastName = "Byard";
       numberAddress = "Main Street";
       phoneNumber = "2313462345";
   }

   Contact(String contactId) {
	   
	    updateContactId(contactId);
	    this.firstName = empty;
	    this.lastName = empty;
	    this.phoneNumber = empty;
	    this.numberAddress = empty;
	  }

	  Contact(String contactId, String firstName) {
		  
	    updateContactId(contactId);
	    updateFirstName(firstName);
	    this.lastName = empty;
	    this.phoneNumber = empty;
	    this.numberAddress = empty;
	  }

	  Contact(String contactId, String firstName, String lastName) {
		  
	    updateContactId(contactId);
	    updateFirstName(firstName);
	    updateLastName(lastName);
	    this.phoneNumber = empty;
	    this.numberAddress = empty;
	  }

	  Contact(String contactId, String firstName, String lastName,String phoneNumber) {
		  
	    updateContactId(contactId);
	    updateFirstName(firstName);
	    updateLastName(lastName);
	    updatePhoneNumber(phoneNumber);
	    this.numberAddress = empty;
	  }

	  Contact(String contactId, String firstName, String lastName,String phoneNumber, String address) {
		  
	    updateContactId(contactId);
	    updateFirstName(firstName);
	    updateLastName(lastName);
	    updatePhoneNumber(phoneNumber);
	    updateAddress(address);
	  }
   
   
   /* setters and getters */
   
   public String getContactID() {
       return contactID;
   }

   public String getFirstName() {
       return firstName;
   }

   public void setFirstName(String firstName) {
       this.firstName = firstName;
   }

   public String getLastName() {
       return lastName;
   }

   public void setLastName(String lastName) {
       this.lastName = lastName;
   }

   public String getNumberAddress() {
       return numberAddress;
   }

   public void setNumberAddress(String numberAddress) {
       this.numberAddress = numberAddress;
   }
   
   public String getPhoneNumber() {
	   return phoneNumber;
   }
   
   public void setPhoneNumber(String phoneNumber) {
	   this.phoneNumber = phoneNumber; 
   }

   // method to compare contacts and check for duplicates 
   
   @Override
   public boolean equals(Object obj) {
       if (this == obj)
           return true;
       
       if (obj == null)
           return false;
       
       if (getClass() != obj.getClass())
           return false;
       
       Contact other = (Contact) obj;
       
       if (contactID == null) {
           if (other.contactID != null)
               return false;
       } else if (!contactID.equals(other.contactID))
           return false;
       if (firstName == null) {
           if (other.firstName != null)
               return false;
       } else if (!firstName.equals(other.firstName))
           return false;
       if (lastName == null) {
           if (other.lastName != null)
               return false;
       } else if (!lastName.equals(other.lastName))
           return false;
       if (numberAddress == null) {
           if (other.numberAddress != null)
               return false;
       } else if (!numberAddress.equals(other.numberAddress))
           return false;
       
       return true;
   }
       
    public void printContact() {
    	
    	System.out.println(contactID);
    	System.out.println(firstName);
    	System.out.println(lastName);
    	System.out.println(numberAddress);
    	System.out.println(phoneNumber);
    	
    }
    
    protected void updateContactId(String contactID) {
        if (contactID == null) {
          throw new IllegalArgumentException("Contact ID cannot be empty");
        } else if (contactID.length() > ID_LENGTH) {
          throw new IllegalArgumentException("Contact ID cannot be longer than " + ID_LENGTH + " characters");
        } else {
          this.contactID = contactID;
        }
      }
    

    protected void updateFirstName(String firstName) {
        if (firstName == null) {
          throw new IllegalArgumentException("First name cannot be empty");
        } else if (firstName.length() > FNAME_LENGTH) {
          throw new IllegalArgumentException("First name cannot be longer than " + FNAME_LENGTH + " characters");
        } else {
          this.firstName = firstName;
        }
      }
   
    protected void updateLastName(String lastName) {
        if (lastName == null) {
          throw new IllegalArgumentException("Last name cannot be empty");
        } else if (lastName.length() > LNAME_LENGTH) {
          throw new IllegalArgumentException("Last name cannot be longer than " + LNAME_LENGTH + " characters");
        } else {
          this.lastName = lastName;
        }
     }

    protected void updateAddress(String numberAddress) {
        if (numberAddress == null) {
          throw new IllegalArgumentException("Address cannot be empty");
        } else if (numberAddress.length() > ADDRESS_LENGTH) {
          throw new IllegalArgumentException("Address cannot be longer than " + ADDRESS_LENGTH + " characters");
        } else {
          this.numberAddress = numberAddress;
        }
      }

    protected void updatePhoneNumber(String phoneNumber) {
        String regex = "[0-9]+";
        if (phoneNumber.length() != PHONE_LENGTH) {
          throw new IllegalArgumentException(
              "Phone number length invalid. Ensure it is " + PHONE_LENGTH + " digits.");
        } else if (!phoneNumber.matches(regex)) {
          throw new IllegalArgumentException(
              "Phone number cannot have anything but numbers");
        } else {
          this.phoneNumber = phoneNumber;
        }
      }
}

