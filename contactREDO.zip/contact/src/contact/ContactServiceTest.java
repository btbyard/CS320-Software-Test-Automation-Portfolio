package contact;

import static org.junit.Assert.*;
import org.junit.Test;

//JUnit will test ContactService class and its methods

public class ContactServiceTest {

   // testing add method to work, when details provided should work 
	
   @Test
   public void testMethodAddPass() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("C001", "Brad", "Byard", "167 Main ST", "0123456789");
       Contact c2 = new Contact("C002", "John", "Doe", "168 Main ST", "0123456788");
       Contact c3 = new Contact("C003", "Jim", "Zilk", "169 Main ST", "0123456787");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c2));
       assertEquals(true, cs.add(c3));
   }

   // testing add method to work fine, when details provided should not work 
   
   @Test
   public void testMethodAddFail() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("C001", "Brad", "Byard", "167 Main ST", "0123456789");
       Contact c2 = new Contact("C002", "John", "Doe", "168 Main ST", "0123456788");
       Contact c3 = new Contact("C003", "Jim", "Zilk", "169 Main ST", "0123456787");
       assertEquals(true, cs.add(c1));
       assertEquals(false, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
   }

   // test delete method passing
   
   @Test
   public void testMethodDeletePass() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("C001", "Brad", "Byard", "167 Main ST", "0123456789");
       Contact c2 = new Contact("C002", "John", "Doe", "168 Main ST", "0123456788");
       Contact c3 = new Contact("C003", "Jim", "Zilk", "169 Main ST", "0123456787");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c2));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.remove("C003"));
       assertEquals(true, cs.remove("C002"));
   }

   // test the delete method Failing
   
   @Test
   public void testMethodDeleteFail() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("C001", "Brad", "Byard", "167 Main ST", "0123456789");
       Contact c2 = new Contact("C002", "John", "Doe", "168 Main ST", "0123456788");
       Contact c3 = new Contact("C003", "Jim", "Zilk", "169 Main ST", "0123456787");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
       assertEquals(false, cs.remove("C004"));
       assertEquals(true, cs.remove("C002"));
   }

   // test the update method passing
   
   @Test
   public void testUpdatePass() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("C001", "Brad", "Byard", "167 Main ST", "0123456789");
       Contact c2 = new Contact("C002", "John", "Doe", "168 Main ST", "0123456788");
       Contact c3 = new Contact("C003", "Jim", "Zilk", "169 Main ST", "0123456787");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
       assertEquals(true, cs.update("C003", "Zach", "Lind", "", "1231231234"));
       assertEquals(true, cs.update("C002", "Jordan", "Poole", "124 LA ST","1233211234"));
   }

   //test the update method failing
   
   @Test
   public void testUpdateFail() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("C001", "Brad", "Byard", "167 Main ST", "0123456789");
       Contact c2 = new Contact("C002", "John", "Doe", "168 Main ST", "0123456788");
       Contact c3 = new Contact("C003", "Jim", "Zilk", "169 Main ST", "0123456787");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
       assertEquals(false, cs.update("C004", "Zach", "Lind", "", "1231231234"));
       assertEquals(true, cs.update("C002", "Jordan", "Poole", "124 LA ST", "1233211234"));
   }

}
